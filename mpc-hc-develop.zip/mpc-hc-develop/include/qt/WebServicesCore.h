#ifndef __WEBSERVICESCORE__
#define __WEBSERVICESCORE__

#ifndef __COREFOUNDATION__
#include "CoreFoundation.h"
#endif


#ifndef __WSMETHODINVOCATION__
#include "WSMethodInvocation.h"
#endif




#endif /* __WEBSERVICESCORE__ */

